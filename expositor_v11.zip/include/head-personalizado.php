<meta name="description" content="<?php echo ucfirst($arts['categoria']); ?>"/>
<meta property="og:image" content="<?php echo $arts['link']; ?>" />
<meta property="twitter:image" content="<?php echo $arts['link']; ?>"/>
<meta property="twitter:description" content="<?php echo ucfirst($arts['categoria']); ?>"/>
<meta property="twitter:title" content="Miguella Art's - Expositor"/>
<meta property="twitter:card" content="summary"/>
